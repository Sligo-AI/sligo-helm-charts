# Temporal (Enterprise)

Sligo can use **Temporal Cloud** (or another external Temporal Service) or run a **self-hosted** Temporal cluster alongside the app stack. The Sligo `sligo-temporal-worker` Deployment is independent of self-hosting: enable it whenever workflows should run. Do not name it `temporal-worker` — that Deployment is the Temporal server internal worker when `temporal.selfHosted` is true.

The official [`temporalio/temporal`](https://github.com/temporalio/helm-charts) Helm subchart (chart `1.2.0`, server `1.31.0`) is installed only when `temporal.selfHosted: true`.

## Temporal Cloud / external (no self-hosted server)

```yaml
temporal:
  enabled: true
  selfHosted: false
  type: external
  frontendAddress: <namespace>.<account>.tmprl.cloud:7233
  namespace: <cloud-namespace>
  taskQueue: sligo-workflows
  web:
    enabled: false

temporalWorker:
  enabled: true
```

Put `TEMPORAL_API_KEY` (and usually `TEMPORAL_TLS=true`) in **`backend-secrets`** (worker reuses it) and **`nextjs-secrets`** (Next app opens its own Temporal client). Terraform does this when `enable_temporal=true` and `temporal_self_hosted=false`.

## Self-hosted (in-cluster server)

Set in your environment values (or via Terraform `enable_temporal=true` with `temporal_self_hosted=true`):

```yaml
temporal:
  enabled: true
  selfHosted: true
  namespace: sligo-prod          # Temporal namespace (not K8s)
  taskQueue: sligo-workflows
  persistence:
    host: <postgres-host>        # managed Postgres private IP / RDS endpoint
    port: 5432
    user: <postgres-user>

temporalWorker:
  enabled: true

temporal-server:
  server:
    config:
      persistence:
        numHistoryShards: 512
        datastores:
          default:
            sql:
              host: <postgres-host>
              user: <postgres-user>
          visibility:
            sql:
              host: <postgres-host>
              user: <postgres-user>
    namespaces:
      create: false              # do not use the subchart Job (races frontend)
  web:
    enabled: true                # ClusterIP only; Super Admin proxy in sligo-app
```

On install/upgrade, `templates/temporal/namespace-job.yaml` waits for `temporal-frontend` then creates `temporal.namespace` (idempotent `describe` then `create`). Keep `temporal.namespaceCreate.enabled: true` (default). Manual equivalent:

```bash
kubectl exec -n sligo deploy/temporal-admintools -- \
  temporal operator namespace create -n <temporal.namespace> --retention 720h
```

For local dev only, use `temporal.enabled: true`, `temporal.selfHosted: false`, `temporal.type: internal` (in-memory `start-dev` — not for production).

## Kubernetes secrets (created by Terraform)

| Secret | Keys | Consumer |
|--------|------|----------|
| `temporal-db-credentials` | `host`, `port`, `database`, `username`, `password` | Temporal default store (self-hosted only) |
| `temporal-visibility-db-credentials` | same | Temporal visibility store (self-hosted only) |
| `backend-secrets` | `TEMPORAL_ADDRESS`, `TEMPORAL_NAMESPACE`, `TEMPORAL_TASK_QUEUE`, `TEMPORAL_TLS`, optional `TEMPORAL_API_KEY` | backend, temporal-worker |
| `nextjs-secrets` | same `TEMPORAL_*` | Next app Temporal client |
| `mcp-gateway-secrets` | `TEMPORAL_*` | MCP gateway (Temporal MCP server) |

When self-hosted, Postgres databases `temporal` and `temporal_visibility` are created by Terraform on the customer's managed Postgres instance (`createDatabase: false`). `manageSchema: true` so the subchart applies Temporal's SQL schema (`schema_version` and versioned migrations). Without that, the server crashes with `relation "schema_version" does not exist`.

## Sizing (defaults, self-hosted server)

| Component | CPU request | Memory request |
|-----------|-------------|----------------|
| frontend | 100m | 256Mi |
| matching | 100m | 256Mi |
| internal-worker | 100m | 256Mi |
| history | 500m | 1Gi |

## Web UI (Super Admin only)

When self-hosted with `temporal.web.enabled: true`, the Temporal Web UI is deployed as `temporal-web:8080` (ClusterIP). It is **not** exposed on a public ingress.

Super Admins open **`/super-admin/temporal`** in sligo-app (a Super Admin page). Temporal Web is iframed from **`/super-admin/temporal/namespaces`**; other nested paths proxy to `TEMPORAL_UI_URL` (default `http://temporal-web:8080`) after a Super Admin session check. Helm `TEMPORAL_UI_PUBLIC_PATH` is `/super-admin/temporal`.

## Upgrades (self-hosted)

When upgrading the Temporal server image or chart:

1. Pin chart and server image together in `Chart.yaml` / `temporal-server.server.image.tag`.
2. Run schema migration (`temporal-sql-tool update-schema`) via the subchart schema hook before or as part of the Helm upgrade.
3. Never run newer server binaries against an older schema.

See [Temporal server upgrades](https://docs.temporal.io/self-hosted-guide/upgrade-server).

## gRPC address

- Self-hosted: Sligo clients use `temporal-frontend:7233` inside the cluster (`temporal.frontendAddress`).
- Temporal Cloud: set `temporal.frontendAddress` to the Cloud endpoint; clients also read `TEMPORAL_*` from secrets.
