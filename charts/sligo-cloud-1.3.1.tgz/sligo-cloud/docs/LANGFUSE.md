# Langfuse (Helm)

Sligo can send traces to **Langfuse Cloud** (or any existing instance) or deploy the official [langfuse-k8s](https://github.com/langfuse/langfuse-k8s) chart in-cluster.

## Modes

| Mode | `langfuse.*` | Notes |
|------|----------------|-------|
| Off (default) | `enabled: false` | No Helm injection. Secrets may still have empty `LANGFUSE_*`. |
| External / Cloud | `enabled: true`, `selfHosted: false` | Point `LANGFUSE_BASE_URL` + keys in nextjs/backend secrets. |
| Self-hosted | `enabled: true`, `selfHosted: true` | Subchart `langfuse-server`. Terraform provisions Postgres DB, blob bucket, ClickHouse operator, and the public UI host. |

## URLs

- **`langfuse.baseUrl`** (default `http://langfuse-web:3000`) — injected as `LANGFUSE_BASE_URL` on app and backend for in-cluster ingest.
- **`langfuse.uiUrl`** — public `https://langfuse.<domain>`. Injected as `LANGFUSE_UI_URL` for the Super Admin launch page.

Do not send SDK traffic through the public hostname.

## Persistence

When self-hosted, ClickHouse, Keeper, and Valkey use PVCs. Valkey `keepPvc` is true. Do not rename volume claims on upgrade. Staging can use 1 ClickHouse + 1 Keeper replica; production should use 3 + 3 (Keeper count must be odd).

ClickHouse requires the ClickHouse operator and cert-manager on the cluster before a real install (`clickhouse.crdCheck` is false in chart defaults so `helm template` works).

## Ingress

Add a second host on the Sligo ingress with `backend: langfuse` (service `langfuse.webServiceName`, default `langfuse-web`). The Langfuse subchart ingress stays disabled so GKE/ALB/AGIC TLS stays on the Sligo ingress.

## Secrets

`LANGFUSE_INIT_*` (org, project, user, public/secret keys) and NextAuth salt/secret are supplied by Terraform as Kubernetes secrets / Helm extra env. Super Admin shows only the UI email and password.

See [documentation/enterprise/langfuse.md](../../../documentation/enterprise/langfuse.md).
